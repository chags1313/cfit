import flet as ft


def main(page: ft.Page):
    def check_workout(e):
        pass

    page.title = "CrossFit Fairmount"
    #page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.appbar = ft.AppBar(
        title = ft.Text("CrossFit Fairmount"),
        center_title=True
    )
    page.floating_action_button = ft.FloatingActionButton(
        text = 'WOD',
        on_click= check_workout
    )
    left_clicker = ft.IconButton(ft.icons.ARROW_LEFT_OUTLINED)
    right_clicker = ft.IconButton(ft.icons.ARROW_RIGHT_OUTLINED)
    day_name = ft.Text("08/10/2023")
    image = ft.Image("C:/Users/tup10143/Downloads/wod.jpg", height = 500)
    image_row = ft.Row(controls = [image], alignment=ft.MainAxisAlignment.CENTER)




    page.add(
        ft.Row(
            [
                left_clicker, day_name, right_clicker
            ],
            alignment=ft.MainAxisAlignment.CENTER
        )
    )
    page.add(image_row)


ft.app(main, view = ft.FLET_APP_WEB, port = 8550)